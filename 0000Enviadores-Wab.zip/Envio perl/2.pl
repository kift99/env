#!/opt/perl/bin/perl -w
use MIME::Lite;
use Getopt::Std;
use Net::SMTP;

my $SMTP_SERVER = '/usr/sbin/sendmail -t';
my $DEFAULT_SENDER = 'dford@tacsea.metapath.com';
my $DEFAULT_RECIPIENT = 'don.ford@metapath.com';

my (%o, $msg);

# process options
getopts('hf:t:s:', \%o);

$o{f} ||= $DEFAULT_SENDER;
$o{t} ||= $DEFAULT_RECIPIENT;
$o{s} ||= 'attachment';

if ($o{h} or !@ARGV) {
die "usage:\n\t$0 -h -f -t -s /var/log/log.txt\n";
}

# construct and send email
$msg = new MIME::Lite(
From => $o{f},
To => $o{t},
Subject => $o{s},
Data => "Hi",
Type => "multipart/mixed",
);

while (@ARGV) {
$msg->attach('Type' => 'application/octet-stream',
'Encoding' => 'base64',
'Path' => shift @ARGV);
}

$msg->send;