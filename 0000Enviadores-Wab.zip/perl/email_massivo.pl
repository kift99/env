#!/usr/bin/perl

use strict;
use warnings;
use MIME::Lite;
use File::Basename;
use POSIX qw(strftime);

###############################
### CONFIGURAÇÕES PRINCIPAIS ###
###############################

# Arquivos e Identificação
my $lista_emails        = 'lista_emails.txt';
my $nome_remetente      = '🛵Sua fatura Combo por 18% OFF!';
my $remetente           = 'support@societyofthegoldenrose.com';
my $arquivo_assunto     = 'assunto.txt';
my $arquivo_corpo       = 'corpo.html.txt';
my $arquivo_anexo       = 'BR20276651-FEV-.pdf';

# Controle de Temporização
my $delay_por_email     = 0;     # Segundos entre e-mails
my $pausa_lote         = 15;    # A cada X e-mails
my $duracao_pausa       = 0;    # Segundos de pausa

# Cores do Terminal (Códigos ANSI)
my $cor_contador   = "\033[38;5;13m";  # Roxo fluorescente
my $cor_horario    = "\x1b[100;71;87m";  # Cinza claro"; # Roxo médio
my $cor_email      = "\033[40;38;5;207m";     # Roxo claro em negrito
my $reset_cor      = "\033[0m";        # Resetar formatação

##############################
### FUNÇÕES AUXILIARES ###
##############################

sub gerar_dados_dinamicos {
    my ($email) = @_;
    
    return {
        data    => strftime("%d/%m/%Y %H:%M", localtime),
        email   => $email,
        numeros => sprintf("%06d", int(rand(900000)) + 100000),
        mix     => join('', map { ('0'..'9','A'..'Z','a'..'z')[rand 62] } 1..10)
    };
}

sub sanitizar_email {
    my ($email) = @_;
    $email =~ s/[^\w\.@+-]//g;        # Remove caracteres especiais
    $email =~ s/\s+//g;               # Remove espaços
    $email = lc($email);              # Normaliza para minúsculas
    return $email;
}

sub validar_email {
    my ($email) = @_;
    return $email =~ /^[\w.+-]+@[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$/i;
}

sub substituir_placeholders {
    my ($texto, $dados) = @_;
    
    $texto =~ s/\[data\]/$dados->{data}/g;
    $texto =~ s/\[email\]/$dados->{email}/g;
    $texto =~ s/\[numeros\]/$dados->{numeros}/g;
    $texto =~ s/\[numeros e letras maiusculas e minusculsa\]/$dados->{mix}/g;
    
    return $texto;
}

sub enviar_email {
    my ($email_obj) = @_;
    
    my $sendmail_path = `which sendmail` || '/usr/sbin/sendmail';
    chomp($sendmail_path);
    
    unless(-x $sendmail_path) {
        die "ERRO: Sendmail não encontrado!\nInstale com:\n" .
            "Debian/Ubuntu: sudo apt install sendmail\n" .
            "RedHat/CentOS: sudo yum install sendmail sendmail-cf\n";
    }

    open(my $pipe, '|-', "$sendmail_path -t -oi") 
        or die "Falha ao abrir Sendmail: $!";
        
    print $pipe $email_obj->as_string;
    close($pipe) or die "Erro no envio: $!";
}

##########################
### EXECUÇÃO PRINCIPAL ###
##########################

# Carregar templates
open(my $fh_assunto, '<', $arquivo_assunto) or die "Erro no assunto: $!";
my $assunto_base = do { local $/; <$fh_assunto> };
close($fh_assunto);

open(my $fh_corpo, '<', $arquivo_corpo) or die "Erro no corpo: $!";
my $corpo_base = do { local $/; <$fh_corpo> };
close($fh_corpo);

# Processar lista de e-mails
open(my $fh_emails, '<', $lista_emails) or die "Erro na lista: $!";

my $contador = 0;
my $inicio = time;
while(my $linha = <$fh_emails>) {
    my $destinatario = sanitizar_email($linha);
    next unless validar_email($destinatario);

    $contador++;
    
    # Construir e-mail
    my $dados = gerar_dados_dinamicos($destinatario);
    
    my $email = MIME::Lite->new(
        From    => "$nome_remetente <$remetente>",
        To      => $destinatario,
        Subject => substituir_placeholders($assunto_base, $dados),
        Type    => 'multipart/mixed'
    );
    
    $email->attach(
        Type => 'text/html',
        Data => substituir_placeholders($corpo_base, $dados)
    );
    
    if(-e $arquivo_anexo) {
        $email->attach(
            Type        => 'application/pdf',
            Path        => $arquivo_anexo,
            Filename    => basename($arquivo_anexo),
            Disposition => 'attachment'
        );
    }

    # Enviar e registrar
    eval {
        enviar_email($email);
        print sprintf("${cor_contador}[%04d]$reset_cor ${cor_horario}%s$reset_cor - ${cor_email}%s$reset_cor\n", 
            $contador,
            strftime("%H:%M:%S", localtime),
            $destinatario);

        sleep($delay_por_email) if $delay_por_email > 0;
        
        if($contador % $pausa_lote == 0) {
            my $progresso = ($contador / (time - $inicio)) * 60;
            print "\n${cor_horario}--- PAUSA: ${duracao_pausa}s | Velocidade: %.2f/min ---$reset_cor\n\n";
            sleep($duracao_pausa);
        }
    };
    
    if($@) {
        warn "\033[1;31mERRO: $destinatario\n$@$reset_cor\n";
        sleep(5);
    }
}

close($fh_emails);

print "\n${cor_contador}═══════════════════════════════════$reset_cor\n";
print " ${cor_horario}Processo finalizado em " . strftime("%Hh%Mm%Ss", localtime(time - $inicio)) . "$reset_cor\n";
print " ${cor_email}Total de e-mails enviados: $contador$reset_cor\n";
print "${cor_contador}═══════════════════════════════════$reset_cor\n";