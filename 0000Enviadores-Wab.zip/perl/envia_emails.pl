#!/usr/bin/perl
use strict;
use warnings;
use utf8;

# Configurações básicas
my $config = {
    remetente_nome  => 'Sua fatura Combo',
    remetente_email => 'suporte@empresa.com',
    arquivo_assunto => 'assunto.txt',
    arquivo_corpo   => 'corpo.html.txt',
    arquivo_emails  => 'lista_emails.txt',
    anexo           => 'BR20276651-FEV-.pdf',
    sendmail_path   => '/usr/sbin/sendmail', # Caminho do Sendmail
    tempo_espera    => 1,    # Segundos entre e-mails
    debug           => 1     # 1 = Mostrar detalhes, 0 = Silencioso
};

#-----------------------------------------------------------------------
# NÃO ALTERE ABAIXO DESTA LINHA
#-----------------------------------------------------------------------

# Módulos necessários
use MIME::Lite;
use Encode qw(encode decode);
use Time::HiRes qw(sleep);

# Verificar e carregar arquivos
verificar_arquivos($config);
my ($assunto, $corpo) = carregar_conteudo($config);
my @emails = carregar_emails($config->{arquivo_emails});

# Criar template do e-mail
my $template_email = criar_template_email($config, $assunto, $corpo);

# Processar envios
enviar_emails($template_email, \@emails, $config);

exit;

#-----------------------------------------------------------------------
sub verificar_arquivos {
    my ($conf) = @_;
    
    print "Verificando arquivos...\n" if $conf->{debug};
    
    for my $arquivo ($conf->{arquivo_assunto}, $conf->{arquivo_corpo}, $conf->{arquivo_emails}, $conf->{anexo}) {
        unless (-f $arquivo) {
            die "ERRO: Arquivo não encontrado: $arquivo";
        }
        print " - $arquivo: OK\n" if $conf->{debug};
    }
}

sub carregar_conteudo {
    my ($conf) = @_;
    
    print "Carregando conteúdo...\n" if $conf->{debug};
    
    open(my $fh, '<:encoding(UTF-8)', $conf->{arquivo_assunto}) or die $!;
    my $assunto = <$fh>;
    close $fh;
    
    open($fh, '<:encoding(UTF-8)', $conf->{arquivo_corpo}) or die $!;
    local $/;
    my $corpo = <$fh>;
    close $fh;
    
    return ($assunto, $corpo);
}

sub carregar_emails {
    my ($arquivo) = @_;
    
    print "Carregando e-mails...\n" if $config->{debug};
    
    open(my $fh, '<:encoding(UTF-8)', $arquivo) or die $!;
    my @emails;
    while (<$fh>) {
        chomp;
        s/^\s+|\s+$//g;
        if (/\S+\@\S+\.\S+/) {
            push @emails, $_;
            print " - E-mail válido: $_\n" if $config->{debug};
        }
        else {
            print "AVISO: E-mail inválido ignorado: $_\n" if $config->{debug};
        }
    }
    close $fh;
    
    return @emails;
}

sub criar_template_email {
    my ($conf, $assunto, $corpo) = @_;
    
    print "Criando template do e-mail...\n" if $conf->{debug};
    
    my $mime = MIME::Lite->new(
        From    => encode('MIME-Header', "$conf->{remetente_nome} <$conf->{remetente_email}>"),
        Subject => encode('MIME-Header', $assunto),
        Type    => 'multipart/mixed',
        Encoding => 'base64',
    );
    
    $mime->attach(
        Type     => 'text/html',
        Data     => encode('UTF-8', $corpo),
        Encoding => 'base64',
    );
    
    $mime->attach(
        Type        => 'application/pdf',
        Path        => $conf->{anexo},
        Filename    => encode('MIME-Header', $conf->{anexo}),
        Disposition => 'attachment',
        Encoding    => 'base64',
    );
    
    return $mime;
}

sub enviar_emails {
    my ($template, $emails, $conf) = @_;
    
    my $total = scalar @$emails;
    my $contador = 0;
    
    print "Iniciando envio de $total e-mails...\n\n";
    
    for my $destinatario (@$emails) {
        $contador++;
        
        # Criar e-mail individual
        my $email = $template->new();
        $email->replace('To' => $destinatario);
        
        # Mostrar progresso
        printf "Enviando %2d/%2d para: %s\n", $contador, $total, $destinatario
            if $conf->{debug};
        
        # Enviar via Sendmail
        my $sucesso = 0;
        open(my $pipe, '|-:encoding(UTF-8)', "$conf->{sendmail_path} -t -oi")
            or warn "ERRO ao abrir sendmail" and next;
        
        $email->print($pipe);
        if (close $pipe) {
            print "  - OK: Enviado com sucesso\n" if $conf->{debug};
            $sucesso = 1;
        }
        else {
            print "  - ERRO: Falha no envio ($!)\n" if $conf->{debug};
        }
        
        # Pausa entre envios
        sleep($conf->{tempo_espera}) if $conf->{tempo_espera} > 0;
    }
    
    print "\nProcesso concluído! Total enviado: $contador\n";
}