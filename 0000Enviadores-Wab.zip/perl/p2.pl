#!/usr/bin/perl

use strict;
use warnings;
use MIME::Lite;
use File::Basename;

my $lista_emails   = 'lista_emails.txt';
my $remetente      = 'support@societyofthegoldenrose.com';
my $arquivo_assunto = 'assunto.txt';
my $arquivo_corpo   = 'corpo.html.txt';
my $arquivo_anexo   = 'BR20276651-FEV-.pdf';

# Ler assunto
open(my $fh_assunto, '<', $arquivo_assunto)
    or die "Não foi possível abrir o arquivo de assunto: $!";
my $assunto = <$fh_assunto>;
chomp($assunto);
close($fh_assunto);

# Ler corpo
open(my $fh_corpo, '<', $arquivo_corpo)
    or die "Não foi possível abrir o arquivo de corpo: $!";
my $corpo = do { local $/; <$fh_corpo> };
close($fh_corpo);

# Ler lista de e-mails
open(my $fh_emails, '<', $lista_emails)
    or die "Não foi possível abrir a lista de e-mails: $!";

# Abre o pipe para sendmail apenas uma vez
open(my $sendmail, '| /usr/sbin/sendmail -t') 
    or die "Erro ao abrir sendmail: $!";

while (my $destinatario = <$fh_emails>) {
    chomp($destinatario);
    next if $destinatario =~ /^\s*$/;  # Ignora linhas em branco

    my $email = MIME::Lite->new(
        From    => $remetente,
        To      => $destinatario,
        Subject => $assunto,
        Type    => 'multipart/mixed',
    );

    # Anexa o corpo
    $email->attach(
        Type => 'text/html',
        Data => $corpo,
    );

    # Verifica se o anexo existe
    if (-e $arquivo_anexo) {
        $email->attach(
            Type        => 'application/pdf',
            Path        => $arquivo_anexo,
            Filename    => basename($arquivo_anexo),
            Disposition => 'attachment',
        );
    } else {
        warn "Arquivo de anexo não encontrado: $arquivo_anexo\n";
    }

    # Envia para o pipe
    print $sendmail $email->as_string . "\n\n";
    print "E-mail enviado para: $destinatario\n";
    
    # Se desejar, inclua um sleep menor:
    # sleep(5);
}

close($fh_emails);
close($sendmail);

print "Todos os e-mails foram enviados.\n";