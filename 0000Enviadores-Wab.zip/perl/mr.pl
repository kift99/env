#!/usr/bin/perl

use strict;
use warnings;
use MIME::Lite;
use File::Basename;

# Configurações Gerais
my $lista_emails = 'lista_emails.txt';
my $nome_remetente = 'Sua fatura Combo por 18% OFF!';
my $remetente = 'support@societyofthegoldenrose.com';
my $arquivo_assunto = 'assunto.txt';
my $arquivo_corpo = 'corpo.html.txt';
my $arquivo_anexo = 'BR20276651-FEV-.pdf';

# Leitura de Arquivos
open(my $fh_assunto, '<', $arquivo_assunto) or die "Não foi possível abrir o arquivo de assunto ($arquivo_assunto): $!";
my $assunto = <$fh_assunto>;
chomp($assunto);
close($fh_assunto);

open(my $fh_corpo, '<', $arquivo_corpo) or die "Não foi possível abrir o arquivo de corpo ($arquivo_corpo): $!";
my $corpo = do { local $/; <$fh_corpo> };
close($fh_corpo);

open(my $fh_emails, '<', $lista_emails) or die "Não foi possível abrir o arquivo de lista de e-mails ($lista_emails): $!";

# Loop para Enviar E-mails
my $contador = 0;
while (my $destinatario = <$fh_emails>) {
    chomp($destinatario);
    next if $destinatario =~ /^\s*$/;

    # Criar o objeto MIME::Lite
    my $email = MIME::Lite->new(
        From    => "$nome_remetente <$remetente>",
        To      => $destinatario,
        Subject => $assunto,
        Type    => 'multipart/mixed',
    );

    # Anexar o corpo do e-mail
    $email->attach(
        Type => 'text/html',
        Data => $corpo,
    );

    # Verificar o arquivo de anexo
    if (-e $arquivo_anexo) {
        $email->attach(
            Type        => 'application/pdf',
            Path        => $arquivo_anexo,
            Filename    => basename($arquivo_anexo),
            Disposition => 'attachment',
        );
    } else {
        warn "Arquivo de anexo não encontrado: $arquivo_anexo\n";
    }

    # Enviar o e-mail
    open(my $sendmail, '| /usr/sbin/sendmail -t') or die "Erro ao abrir o sendmail: $!";
    print $sendmail $email->as_string;
    close($sendmail);

    print "E-mail enviado para: $destinatario\n";

    # Incrementar o contador e fazer a pausa de 5 segundos
    $contador++;
    if ($contador % 100 == 0) {
        sleep(5);
    }
}

close($fh_emails);
print "Todos os e-mails foram enviados.\n";